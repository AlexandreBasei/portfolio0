document.addEventListener('DOMContentLoaded', function () {

    'use strict';

    if (window.innerWidth > 1280) {
        document.getElementById("ico1").setAttribute("colors", "primary:#000000");
        document.getElementById("ico2").setAttribute("colors", "primary:#000000");
    }
});