<?php

define("HOST", 'servd162214.srv.odns.fr');
define("USER", 'abasei@alexandre.basei.mmi-velizy.fr');
define("PWD", '}hNr{n%B)WL~');
define("PORT", 465);